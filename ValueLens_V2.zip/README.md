# ValueLens V2

A polished smartphone-intelligence front-end prototype.

## Included
- 30-phone catalogue
- Local SVG product artwork so phone visuals are present without external image dependencies
- Search and sorting
- Launch/current price and depreciation
- Value score
- Individual phone detail modal with price-history visualization
- AI Finder prototype
- Responsive UI

## Run locally
Because the app loads `data.json`, use a small local web server instead of opening index.html directly.

Python:
`python -m http.server 8000`

Then open:
`http://localhost:8000`

## Production work still required
- Replace illustrative prices with verified/licensed price data.
- Replace generated placeholder phone artwork with properly licensed product images.
- Add a real database/API.
- Add real historical observations rather than interpolated demo chart points.
- Connect an LLM API for natural-language requirement extraction.
- Move recommendation scoring to the server.
- Add admin tools, analytics, rate limiting, error handling and legal pages.
